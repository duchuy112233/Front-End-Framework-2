function App() {
  return (
    <>
      <h1 className="text-center">WEB209 + WEB502 - REACT + TYPESCRIPT - HOADV</h1>
    </>
  );
}

export default App;
